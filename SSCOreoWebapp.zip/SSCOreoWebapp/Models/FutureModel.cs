﻿namespace SSCOreoWebapp.Models
{
    public class FutureModel
    {
        public string Value { get; set; }
        public string Date { get; set; }
    }
}
