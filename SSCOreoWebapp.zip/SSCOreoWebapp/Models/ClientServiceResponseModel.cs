﻿namespace SSCOreoWebapp.Models
{
    public class ClientServiceResponseModel
    {
        public string ServiceName { get; set; }
        public double Amount { get; set; }
        public string Percentage { get; set; }
    }
}
